package swiggy.swiggy;
import org.junit.jupiter.api.Test;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;
public class Dice {
	private int sides;
    private Random random;

    public Dice(int sides) {
        if (sides < 1) {
            throw new IllegalArgumentException("Die must have at least one side.");
        }
        this.sides = sides;
        this.random = new Random();
    }

    public int roll() {
        return random.nextInt(sides) + 1;
    }
}

