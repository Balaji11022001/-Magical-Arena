package swiggy.swiggy;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class BeforeEachAfterEach {
	
	@Test
	public void method1()
	{
		System.out.println("Hello Junit");
	}

	
}

