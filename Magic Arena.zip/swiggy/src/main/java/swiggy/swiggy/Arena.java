package swiggy.swiggy;

public class Arena {
	 private Player playerA;
	    private Player playerB;
	    private Dice attackDie;
	    private Dice defendDie;

	    public Arena(Player playerA, Player playerB) {
	        this.playerA = playerA;
	        this.playerB = playerB;
	        this.attackDie = new Dice(6);
	        this.defendDie = new Dice(6);
	    }

	    public void startBattle() {
	        while (playerA.getHealth() > 0 && playerB.getHealth() > 0) {
	            if (playerA.getHealth() <= playerB.getHealth()) {
	                attack(playerA, playerB);
	            } else {
	                attack(playerB, playerA);
	            }
	        }
	        if (playerA.getHealth() <= 0) {
	            System.out.println(playerA.getName() + " is dead. " + playerB.getName() + " wins!");
	        } else {
	            System.out.println(playerB.getName() + " is dead. " + playerA.getName() + " wins!");
	        }
	    }

	    private void attack(Player attacker, Player defender) {
	        int attackRoll = attackDie.roll();
	        int defendRoll = defendDie.roll();

	        int attackDamage = attacker.getAttack() * attackRoll;
	        int defendDamage = defender.getStrength() * defendRoll;

	        int damage = attackDamage - defendDamage;
	        if (damage > 0) {
	            defender.reduceHealth(damage);
	            System.out.println(attacker.getName() + " attacks " + defender.getName() + " for " + damage + " damage.");
	        } else {
	            System.out.println(defender.getName() + " defends the attack.");
	        }
	    }
}
