package swiggy.swiggy;

import static org.testng.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class PlayerTest {
	@Test
    void testReduceHealth() {
        Player player = new Player("Test Player", 100, 10, 5);
        player.reduceHealth(10);
        assertEquals(90, player.getHealth());
    }

}
